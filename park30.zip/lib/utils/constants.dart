class AppConstants {
  // Marwadi University Coordinates
  static const double parkingLatitude = 22.3697;
  static const double parkingLongitude = 70.8022;
}
