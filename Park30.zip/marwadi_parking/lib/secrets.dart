class Secrets {
  // TODO: Replace with your credentials
  static const String gmailEmail = 'park30.2025@gmail.com';
  static const String gmailAppPassword = 'rwvd nehq absm qcor'; 
}
