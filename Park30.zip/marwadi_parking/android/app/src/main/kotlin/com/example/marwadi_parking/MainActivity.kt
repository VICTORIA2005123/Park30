package com.example.marwadi_parking

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
